﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RegistroAlumnos.Models
{
    public class StudentData
    {
 
        public string Nombre { get; set; }

        public string ApPaterno { get; set; }

        public string ApMaterno { get; set; }

        public string Genero { get; set; }

        public string RFC { get; set; }

        public string Activo { get; set; }

        public string FechaNacimiento { get; set; }

    }
}