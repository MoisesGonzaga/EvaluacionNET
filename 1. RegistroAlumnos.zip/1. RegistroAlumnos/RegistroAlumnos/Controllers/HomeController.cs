﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RegistroAlumnos.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Models.StudentData student)
        {

            string nombre = student.Nombre + " " + student.ApPaterno + " " + student.ApMaterno;
            string gender = student.Genero;
            string rfc = student.RFC;
            string activo = student.Activo;
            string fechaNac = student.FechaNacimiento;

            string fullData = nombre + "," + gender + "," + rfc + "," + activo + "," + fechaNac;
            string fileName = rfc + ".txt";

            string fullFileName = Server.MapPath("~/Alumnos/" + fileName);
            
            StreamWriter streamWriter =
                new StreamWriter(new FileStream(fullFileName, FileMode.Create, FileAccess.Write));
            streamWriter.Write(fullData);
            streamWriter.Close();

            return View();
        }
    }
}