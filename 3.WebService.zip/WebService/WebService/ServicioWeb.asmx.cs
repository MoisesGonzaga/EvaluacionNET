﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml;

namespace WebService
{
    /// <summary>
    /// Summary description for ServicioWeb
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ServicioWeb : System.Web.Services.WebService
    {
        
        

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public bool ValidarRFC(string RFC, XmlDocument xdoc)
        {

            //xdoc.Load("c:/AUCI941201L69/CFDI_101.xml");

            XmlNodeList xEmisor = xdoc.GetElementsByTagName("cfdi:Emisor");
            string xrfcXML = ((XmlElement)xEmisor[0]).GetElementsByTagName("Rfc").ToString();

            if (RFC == xrfcXML)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        [WebMethod]
        public bool ValidarVersion(string RFC, XmlDocument xdoc)
        {
            
            //xdoc.Load("c:/AUCI941201L69/CFDI_101.xml");

            XmlNodeList xEmisor = xdoc.GetElementsByTagName("cfdi:Comprobante");
            string xVerXML = ((XmlElement)xEmisor[0]).GetElementsByTagName("version").ToString();

            if (xVerXML == "3.3")
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        [WebMethod]
        public void ValidarDatos(string RFC, XmlDocument xdoc)
        {
            bool suma = false;
            //xdoc.Load("c:/AUCI941201L69/CFDI_101.xml");

            XmlNodeList xTag = xdoc.GetElementsByTagName("");
            string xXML = ((XmlElement)xTag[0]).GetElementsByTagName("").ToString();
            
        }
    }
}
